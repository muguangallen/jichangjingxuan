export interface SiteConfig {
  brandName: string;
  name: string;
  shortName: string;
  title: string;
  description: string;
  url: string;
  locale: string;
  defaultOgImage: string;
  author: {
    name: string;
    avatar: string;
    bio: string;
  };
}

export const siteConfig: SiteConfig = {
  brandName: '网络连接服务资讯网',
  name: '网络连接服务品牌官方资讯与服务中心',
  shortName: '网络连接服务资讯网',
  title: '网络连接服务选型与节点性能资讯 - 机场推荐|稳定机场|IPLC专线|节点测速',
  description: '面向中文用户的网络连接服务品牌官方资讯与服务中心。整理各大服务商线路架构、节点分布与套餐说明，提供客观选型参考与避坑建议。',
  url: 'https://network2026.example.com',
  locale: 'zh-CN',
  defaultOgImage: '/og/default-og.png',
  author: {
    name: '网络连接服务品牌官方资讯与服务中心',
    avatar: '/images/author-avatar.png',
    bio: '网络连接服务品牌官方资讯团队，负责搜集与整理各大网络连接服务提供商的公开线路规格、节点配置与服务动态。'
  }
};
